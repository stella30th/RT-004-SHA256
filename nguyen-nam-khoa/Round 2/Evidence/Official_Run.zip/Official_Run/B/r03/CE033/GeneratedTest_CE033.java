package org.example;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GeneratedTest_CE033 {

@Test
public void testCaesarDecipherBasic() {
    DecryptionUtils utils = new DecryptionUtils("key");
    String ciphertext = "Khoor Zruog!";
    String expected = "Hello World!";
    assertEquals(expected, utils.caesarDecipher(ciphertext, 3));
}

@Test
public void testCaesarDecipherWrapAroundAndShiftModulo() {
    DecryptionUtils utils = new DecryptionUtils("key");
    // Shift 1 wrapping 'a' to 'z' and 'A' to 'Z'
    assertEquals("zab ZAB", utils.caesarDecipher("abc ABC", 1));
    // Shift 29 is equivalent to shift 3 (29 % 26 = 3)
    assertEquals("Hello World!", utils.caesarDecipher("Khoor Zruog!", 29));
}

@Test
public void testCaesarDecipherNonAlphabetAndEmpty() {
    DecryptionUtils utils = new DecryptionUtils("key");
    assertEquals("", utils.caesarDecipher("", 5));
    assertEquals("12345 @#!?", utils.caesarDecipher("12345 @#!?", 7));
}

@Test
public void testVigenereDecipherBasic() {
    DecryptionUtils utils = new DecryptionUtils("key");
    assertEquals("hello", utils.vigenereDecipher("rijvs"));
}

@Test
public void testVigenereDecipherMixedCaseAndPunctuation() {
    DecryptionUtils utils = new DecryptionUtils("KEY");
    // Non-letters should not advance the key index
    assertEquals("Hello, World!", utils.vigenereDecipher("Rijvs, Uyvjn!"));
}

@Test
public void testVigenereDecipherEmptyString() {
    DecryptionUtils utils = new DecryptionUtils("secret");
    assertEquals("", utils.vigenereDecipher(""));
}

@Test
public void testRailFenceDecipherBasicThreeRails() {
    DecryptionUtils utils = new DecryptionUtils("unused");
    assertEquals("HELLO WORLD", utils.railFenceDecipher("HOREL OLLWD", 3));
}

@Test
public void testRailFenceDecipherTwoRails() {
    DecryptionUtils utils = new DecryptionUtils("unused");
    assertEquals("HELLO", utils.railFenceDecipher("HLOEL", 2));
}

@Test
public void testRailFenceDecipherEmptyString() {
    DecryptionUtils utils = new DecryptionUtils("unused");
    assertEquals("", utils.railFenceDecipher("", 3));
}

}