package org.example;

import org.junit.Rule; import org.junit.Test; import
org.junit.rules.TemporaryFolder;

import java.io.File; import java.io.IOException; import java.util.List; import
java.util.Map;

import static org.junit.Assert.assertEquals; import static
org.junit.Assert.assertTrue;

public class GeneratedTest_CE079 {

@Rule
public TemporaryFolder tempFolder = new TemporaryFolder();

@Test
public void testWriteAndReadFile() throws IOException {
    File file = tempFolder.newFile("test_write_read.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String content = "Hello JUnit 4!";
    processor.write_file(content);

    String readResult = processor.read_file();
    assertEquals("File content should match what was written", content, readResult);
}

@Test
public void testReadFileAsJsonJsonObject() throws IOException {
    File file = tempFolder.newFile("test_object.json");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String jsonContent = "{\"name\": \"Alice\", \"age\": 30}";
    processor.write_file(jsonContent);

    Object result = processor.read_file_as_json();
    assertTrue("Parsed JSON object should be a Map", result instanceof Map);

    Map<?, ?> map = (Map<?, ?>) result;
    assertEquals("Alice", map.get("name"));
    assertEquals(30, map.get("age"));
}

@Test
public void testReadFileAsJsonJsonArray() throws IOException {
    File file = tempFolder.newFile("test_array.json");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String jsonArrayContent = "[\"apple\", \"banana\", \"cherry\"]";
    processor.write_file(jsonArrayContent);

    Object result = processor.read_file_as_json();
    assertTrue("Parsed JSON array should be a List", result instanceof List);

    List<?> list = (List<?>) result;
    assertEquals(3, list.size());
    assertEquals("apple", list.get(0));
    assertEquals("banana", list.get(1));
    assertEquals("cherry", list.get(2));
}

@Test
public void testProcessFileFiltersNonAlphabetCharacters() throws IOException {
    File file = tempFolder.newFile("test_process.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String rawContent = "Hello, World! 12345 @#$\n\t";
    processor.write_file(rawContent);

    String processed = processor.process_file();
    assertEquals("HelloWorld", processed);

    String fileContentAfterProcess = processor.read_file();
    assertEquals("File content on disk should be updated with processed result", "HelloWorld", fileContentAfterProcess);
}

@Test
public void testProcessFileWithNoAlphabetCharacters() throws IOException {
    File file = tempFolder.newFile("test_no_alpha.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("1234567890!@#$%^&*()_+-=[]{}|;':\",./<>?");

    String processed = processor.process_file();
    assertEquals("", processed);
    assertEquals("", processor.read_file());
}

@Test
public void testProcessFileWithOnlyAlphabetCharacters() throws IOException {
    File file = tempFolder.newFile("test_pure_alpha.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String original = "PureAlphabeticString";
    processor.write_file(original);

    String processed = processor.process_file();
    assertEquals(original, processed);
    assertEquals(original, processor.read_file());
}

}