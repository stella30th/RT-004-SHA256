package org.example;

import org.junit.Rule; import org.junit.Test; import
org.junit.rules.TemporaryFolder;

import java.io.File; import java.io.IOException; import java.util.Map;

import static org.junit.Assert.assertEquals; import static
org.junit.Assert.assertNotNull; import static org.junit.Assert.assertTrue;

public class GeneratedTest_CE079 {

@Rule
public TemporaryFolder tempFolder = new TemporaryFolder();

@Test
public void testWriteAndReadFile() throws IOException {
    File file = tempFolder.newFile("test_rw.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String content = "Hello JUnit 4\nLine 2";
    processor.write_file(content);

    String readBack = processor.read_file();
    assertEquals(content, readBack);
}

@Test
public void testProcessFileFiltersNonAlphabeticalCharacters() throws IOException {
    File file = tempFolder.newFile("test_process.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("Hello, World! 12345 -- \t\n");
    String result = processor.process_file();

    assertEquals("HelloWorld", result);
    // Verify file content was also updated
    String fileContent = processor.read_file();
    assertEquals("HelloWorld", fileContent);
}

@Test
public void testProcessFileWithOnlyNonAlphabeticReturnsEmpty() throws IOException {
    File file = tempFolder.newFile("test_empty.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("12345!@#$%^&*()_+ \n\r\t");
    String result = processor.process_file();

    assertEquals("", result);
    assertEquals("", processor.read_file());
}

@Test
public void testReadFileAsJson() throws IOException {
    File file = tempFolder.newFile("test.json");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String jsonContent = "{\"name\":\"Alice\",\"age\":30}";
    processor.write_file(jsonContent);

    Object jsonObject = processor.read_file_as_json();
    assertNotNull(jsonObject);
    assertTrue(jsonObject instanceof Map);

    @SuppressWarnings("unchecked")
    Map<String, Object> map = (Map<String, Object>) jsonObject;
    assertEquals("Alice", map.get("name"));
    assertEquals(30, map.get("age"));
}

@Test(expected = IOException.class)
public void testReadNonExistentFileThrowsException() throws IOException {
    File nonExistent = new File(tempFolder.getRoot(), "missing.txt");
    TextFileProcessor processor = new TextFileProcessor(nonExistent.getAbsolutePath());

    processor.read_file();
}

}