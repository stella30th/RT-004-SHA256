package org.example;

import org.junit.Before; import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals; import static
org.junit.Assert.assertTrue;

public class GeneratedTest_CE073 {

private SplitSentence splitSentence;

@Before
public void setUp() {
    splitSentence = new SplitSentence();
}

@Test
public void testSplitSentencesBasic() {
    String input = "Hello world. How are you? Everything is fine.";
    List<String> result = splitSentence.splitSentences(input);

    assertEquals(3, result.size());
    assertEquals("Hello world.", result.get(0));
    assertEquals("How are you?", result.get(1));
    assertEquals("Everything is fine.", result.get(2));
}

@Test
public void testSplitSentencesWithAbbreviations() {
    String input = "Dr. Smith visited Mr. White at 8 a.m. They had a meeting.";
    List<String> result = splitSentence.splitSentences(input);

    assertEquals(2, result.size());
    assertEquals("Dr. Smith visited Mr. White at 8 a.m.", result.get(0));
    assertEquals("They had a meeting.", result.get(1));
}

@Test
public void testSplitSentencesSingleAndEmpty() {
    List<String> emptyResult = splitSentence.splitSentences("");
    assertTrue(emptyResult.isEmpty());

    String singleSentence = "This is a single sentence without terminal punctuation";
    List<String> singleResult = splitSentence.splitSentences(singleSentence);
    assertEquals(1, singleResult.size());
    assertEquals(singleSentence, singleResult.get(0));
}

@Test
public void testCountWords() {
    assertEquals(4, splitSentence.countWords("This is a test."));
    assertEquals(2, splitSentence.countWords("Hello, world!"));
    assertEquals(3, splitSentence.countWords("Item 123 and 456 count."));
}

@Test
public void testProcessTextFile() {
    String text = "Small sentence. This one contains seven distinct English words. Short again.";
    int maxWords = splitSentence.processTextFile(text);

    assertEquals(7, maxWords);
}

@Test
public void testProcessTextFileEmpty() {
    int maxWords = splitSentence.processTextFile("");
    assertEquals(0, maxWords);
}

}