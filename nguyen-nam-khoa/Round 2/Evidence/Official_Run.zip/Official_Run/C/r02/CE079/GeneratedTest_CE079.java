package org.example;

import org.junit.Rule; import org.junit.Test; import
org.junit.rules.TemporaryFolder;

import java.io.File; import java.io.IOException; import java.util.List; import
java.util.Map;

import static org.junit.Assert.assertEquals; import static
org.junit.Assert.assertTrue; import static org.junit.Assert.fail;

public class GeneratedTest_CE079 {

@Rule
public TemporaryFolder temporaryFolder = new TemporaryFolder();

@Test
public void testWriteAndReadFile() throws IOException {
    File file = temporaryFolder.newFile("test_write_read.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    String content = "Hello World! Line 1\nLine 2";
    processor.write_file(content);

    String readBack = processor.read_file();
    assertEquals(content, readBack);
}

@Test
public void testProcessFileRemovesNonAlphabeticalAndOverwrites() throws IOException {
    File file = temporaryFolder.newFile("test_process.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("Hello, World! 12345 #$%^ \n\t Java");
    String processed = processor.process_file();

    assertEquals("HelloWorldJava", processed);
    assertEquals("HelloWorldJava", processor.read_file());
}

@Test
public void testProcessFileOnlySpecialCharactersResultsInEmpty() throws IOException {
    File file = temporaryFolder.newFile("test_special_chars.txt");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("1234567890!@#$%^&*()_+-=[]{}|;':\",.<>/?\n\t ");
    String processed = processor.process_file();

    assertEquals("", processed);
    assertEquals("", processor.read_file());
}

@Test
public void testReadFileAsJsonMap() throws IOException {
    File file = temporaryFolder.newFile("test_json_map.json");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("{\"name\":\"Alice\",\"age\":25,\"active\":true}");
    Object result = processor.read_file_as_json();

    assertTrue(result instanceof Map);
    @SuppressWarnings("unchecked")
    Map<String, Object> map = (Map<String, Object>) result;

    assertEquals("Alice", map.get("name"));
    assertEquals(25, ((Number) map.get("age")).intValue());
    assertEquals(Boolean.TRUE, map.get("active"));
}

@Test
public void testReadFileAsJsonList() throws IOException {
    File file = temporaryFolder.newFile("test_json_list.json");
    TextFileProcessor processor = new TextFileProcessor(file.getAbsolutePath());

    processor.write_file("[\"first\", \"second\", \"third\"]");
    Object result = processor.read_file_as_json();

    assertTrue(result instanceof List);
    @SuppressWarnings("unchecked")
    List<Object> list = (List<Object>) result;

    assertEquals(3, list.size());
    assertEquals("first", list.get(0));
    assertEquals("second", list.get(1));
    assertEquals("third", list.get(2));
}

@Test(expected = IOException.class)
public void testReadNonExistentFileThrowsException() throws IOException {
    File nonExistent = new File(temporaryFolder.getRoot(), "missing_file.txt");
    TextFileProcessor processor = new TextFileProcessor(nonExistent.getAbsolutePath());
    processor.read_file();
}

}