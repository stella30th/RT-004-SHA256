package org.example;

import org.junit.Before; import org.junit.Test;

import java.util.ArrayList; import java.util.Arrays; import java.util.List;

import static org.junit.Assert.*;

public class GeneratedTest_CE039 {

private ExpressionCalculator calculator;

@Before
public void setUp() {
    calculator = new ExpressionCalculator();
}

@Test
public void testIsOperator() {
    assertTrue(calculator.isOperator('+'));
    assertTrue(calculator.isOperator('-'));
    assertTrue(calculator.isOperator('*'));
    assertTrue(calculator.isOperator('/'));
    assertTrue(calculator.isOperator('%'));

    assertFalse(calculator.isOperator('('));
    assertFalse(calculator.isOperator(')'));
    assertFalse(calculator.isOperator('~'));
    assertFalse(calculator.isOperator('^'));
    assertFalse(calculator.isOperator('0'));
    assertFalse(calculator.isOperator(' '));
}

@Test
public void testCompare() {
    // compare(op1, op2) evaluates priority(op2) >= priority(op1)
    // '+' has priority 1, '*' has priority 2
    assertTrue(calculator.compare('+', '*'));
    assertFalse(calculator.compare('*', '+'));

    // Equal priorities
    assertTrue(calculator.compare('+', '+'));
    assertTrue(calculator.compare('*', '/'));
    assertTrue(calculator.compare('/', '*'));

    // Modulo '%' is mapped to '/' (priority 2)
    assertTrue(calculator.compare('%', '*'));
    assertTrue(calculator.compare('*', '%'));
    assertTrue(calculator.compare('+', '%'));
    assertFalse(calculator.compare('%', '+'));
}

@Test
public void testTransform() {
    // Removes spaces
    assertEquals("1+2", calculator.transform("1 + 2"));

    // -(...) pattern is converted to 0-(...)
    assertEquals("0-(3+4)", calculator.transform("-(3 + 4)"));

    // Minus sign without parenthesis becomes ~
    assertEquals("~5", calculator.transform("- 5"));
    assertEquals("5~2", calculator.transform("5 - 2"));

    // Normal expressions without '-' keep operators and remove spaces
    assertEquals("2*3+4/2", calculator.transform("2 * 3 + 4 / 2"));
}

@Test
public void testPrepare() {
    // Precedence check: 2 + 3 * 4 -> ["2", "3", "4", "*", "+"]
    calculator.prepare("2+3*4");
    List<String> expected1 = Arrays.asList("2", "3", "4", "*", "+");
    assertEquals(expected1, new ArrayList<>(calculator.postfixStack));

    // Mixed precedence with lower operator later: 2 * 3 + 4 -> ["2", "3", "*", "4", "+"]
    calculator.prepare("2*3+4");
    List<String> expected2 = Arrays.asList("2", "3", "*", "4", "+");
    assertEquals(expected2, new ArrayList<>(calculator.postfixStack));

    // Parentheses override precedence: (2+3)*4 -> ["2", "3", "+", "4", "*"]
    calculator.prepare("(2+3)*4");
    List<String> expectedParentheses = Arrays.asList("2", "3", "+", "4", "*");
    assertEquals(expectedParentheses, new ArrayList<>(calculator.postfixStack));
}

@Test
public void testCalculateBasicArithmeticAndPrecedence() {
    assertEquals(5.0, calculator.calculate("2 + 3"), 1e-9);
    assertEquals(14.0, calculator.calculate("2 + 3 * 4"), 1e-9);
    assertEquals(10.0, calculator.calculate("2 * 3 + 4"), 1e-9);
    assertEquals(4.0, calculator.calculate("2.5 + 1.5"), 1e-9);
}

@Test
public void testCalculateWithParenthesesAndUnaryMinus() {
    assertEquals(20.0, calculator.calculate("(2 + 3) * 4"), 1e-9);
    assertEquals(14.0, calculator.calculate("2 * (3 + 4)"), 1e-9);

    // -(expression) handled through transform -> 0-(expression)
    assertEquals(-7.0, calculator.calculate("-(3 + 4)"), 1e-9);
    assertEquals(-20.0, calculator.calculate("-((2 + 3) * 4)"), 1e-9);
}

@Test
public void testCalculateModuloAndDivision() {
    assertEquals(1.0, calculator.calculate("10 % 3"), 1e-9);
    assertEquals(2.5, calculator.calculate("5 / 2"), 1e-9);
    assertEquals(3.0, calculator.calculate("15 / (3 + 2)"), 1e-9);
}

@Test
public void testCalculateHelperMethod() {
    assertEquals(12.0, calculator._calculate(7.0, 5.0, '+'), 1e-9);
    assertEquals(2.0, calculator._calculate(7.0, 5.0, '-'), 1e-9);
    assertEquals(35.0, calculator._calculate(7.0, 5.0, '*'), 1e-9);
    assertEquals(2.0, calculator._calculate(10.0, 5.0, '/'), 1e-9);
    assertEquals(1.0, calculator._calculate(10.0, 3.0, '%'), 1e-9);

    try {
        calculator._calculate(2.0, 3.0, '^');
        fail("Expected IllegalArgumentException for unsupported operator");
    } catch (IllegalArgumentException e) {
        assertTrue(e.getMessage().contains("Unsupported operator"));
    }
}

}