package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE035 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.EightPuzzle");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"findBlank", "move", "getPossibleMoves", "solve"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in EightPuzzle", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        int[][] state={{1,2,3},{4,5,6},{7,0,8}};EightPuzzle p=new EightPuzzle(state);org.junit.Assert.assertArrayEquals(new int[]{2,1},p.findBlank(state));org.junit.Assert.assertEquals(java.util.List.of("up","left","right"),p.getPossibleMoves(state));org.junit.Assert.assertEquals(java.util.List.of("right"),p.solve());
    }
}
