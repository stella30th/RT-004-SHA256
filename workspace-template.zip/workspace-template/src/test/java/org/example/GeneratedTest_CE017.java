package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE017 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.Calculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"calculate"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in Calculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        Calculator c=new Calculator();org.junit.Assert.assertEquals(7.0,c.calculate("1+2*3"),1e-9);org.junit.Assert.assertEquals(9.0,c.calculate("(1+2)*3"),1e-9);org.junit.Assert.assertNull(c.calculate(""));
    }
}
