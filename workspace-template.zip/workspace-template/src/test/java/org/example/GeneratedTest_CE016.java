package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE016 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BoyerMooreSearch");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"badCharacterHeuristic"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BoyerMooreSearch", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(java.util.List.of(0),new BoyerMooreSearch("ababa","aba").badCharacterHeuristic());org.junit.Assert.assertEquals(java.util.List.of(0,1,2),new BoyerMooreSearch("ab","").badCharacterHeuristic());org.junit.Assert.assertTrue(new BoyerMooreSearch("abc","z").badCharacterHeuristic().isEmpty());
    }
}
