package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE008 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BalancedBrackets");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"clearExpr", "checkBalancedBrackets", "getExpr"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BalancedBrackets", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        BalancedBrackets a=new BalancedBrackets("a{b[(c)]}");org.junit.Assert.assertTrue(a.checkBalancedBrackets());org.junit.Assert.assertEquals("{[()]}",a.getExpr());org.junit.Assert.assertFalse(new BalancedBrackets("([)]").checkBalancedBrackets());
    }
}
