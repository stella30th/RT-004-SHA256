package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE012 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BitStatusUtil");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"add", "has", "remove", "check"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BitStatusUtil", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(6,BitStatusUtil.add(2,4));org.junit.Assert.assertTrue(BitStatusUtil.has(6,2));org.junit.Assert.assertFalse(BitStatusUtil.has(2,4));org.junit.Assert.assertEquals(4,BitStatusUtil.remove(6,2));try{BitStatusUtil.check(3);org.junit.Assert.fail("Expected rejection");}catch(IllegalArgumentException expected){}
    }
}
