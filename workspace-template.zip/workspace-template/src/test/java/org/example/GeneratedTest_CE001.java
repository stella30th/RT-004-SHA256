package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE001 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.AccessGatewayFilter");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"filter", "isStartWith", "getJwtUser", "setCurrentUserInfoAndLog"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in AccessGatewayFilter", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        AccessGatewayFilter f = new AccessGatewayFilter(); org.junit.Assert.assertTrue(f.isStartWith("/api/users")); org.junit.Assert.assertTrue(f.isStartWith("/login")); org.junit.Assert.assertFalse(f.isStartWith("/private"));
    }
}
