package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE014 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BookManagement");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"addBook", "removeBook", "viewInventory", "viewBookQuantity"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BookManagement", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        BookManagement b=new BookManagement();b.addBook("A",3);b.addBook("A",2);org.junit.Assert.assertEquals(5,b.viewBookQuantity("A"));b.removeBook("A",5);org.junit.Assert.assertEquals(0,b.viewBookQuantity("A"));org.junit.Assert.assertTrue(b.viewInventory().isEmpty());
    }
}
