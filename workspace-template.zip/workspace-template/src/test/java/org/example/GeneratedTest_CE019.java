package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE019 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.CamelCaseMap");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"get", "put", "remove", "keySet", "size"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in CamelCaseMap", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        CamelCaseMap m=new CamelCaseMap();m.put("first_name","Ada");org.junit.Assert.assertEquals("Ada",m.get("firstName"));org.junit.Assert.assertEquals(1,m.size());m.remove("first_name");org.junit.Assert.assertEquals(0,m.size());
    }
}
