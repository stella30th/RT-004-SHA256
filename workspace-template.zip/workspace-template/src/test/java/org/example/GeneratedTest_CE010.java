package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE010 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BigNumCalculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"add", "subtract", "multiply"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BigNumCalculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals("1000",BigNumCalculator.add("999","1"));org.junit.Assert.assertEquals("-2",BigNumCalculator.subtract("1","3"));org.junit.Assert.assertEquals("0",BigNumCalculator.subtract("100","100"));org.junit.Assert.assertEquals("56088",BigNumCalculator.multiply("123","456"));
    }
}
