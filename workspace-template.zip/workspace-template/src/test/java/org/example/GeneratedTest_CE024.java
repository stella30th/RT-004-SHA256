package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE024 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.CombinationCalculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"count", "countAll", "select", "selectAll"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in CombinationCalculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(10,CombinationCalculator.count(5,2));org.junit.Assert.assertEquals(1,CombinationCalculator.count(5,0));org.junit.Assert.assertEquals(7.0,CombinationCalculator.countAll(3),0);org.junit.Assert.assertEquals(3,new CombinationCalculator(java.util.List.of("a","b","c")).select(2).size());
    }
}
