package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE028 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.CurrencyConverter");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"convert", "getSupportedCurrencies", "addCurrencyRate", "updateCurrencyRate", "getRates"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in CurrencyConverter", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        CurrencyConverter c=new CurrencyConverter();org.junit.Assert.assertEquals(85.0,c.convert(100,"USD","EUR"),1e-9);org.junit.Assert.assertEquals(-1,c.convert(1,"BAD","USD"),0);org.junit.Assert.assertTrue(c.addCurrencyRate("VND",25000));org.junit.Assert.assertFalse(c.addCurrencyRate("VND",2));org.junit.Assert.assertTrue(c.updateCurrencyRate("VND",24000));
    }
}
