package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE037 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.EncryptionUtils");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"caesarCipher", "vigenereCipher", "railFenceCipher"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in EncryptionUtils", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        EncryptionUtils e=new EncryptionUtils("LEMON");org.junit.Assert.assertEquals("Def!",e.caesarCipher("Abc!",3));org.junit.Assert.assertEquals("LXFOPVEFRNHR",e.vigenereCipher("ATTACKATDAWN"));
    }
}
