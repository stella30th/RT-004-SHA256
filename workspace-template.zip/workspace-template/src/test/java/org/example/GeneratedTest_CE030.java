package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE030 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.DataStatistics");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"mean", "median", "mode"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in DataStatistics", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        DataStatistics s=new DataStatistics();org.junit.Assert.assertEquals(2.5,s.mean(new int[]{1,2,3,4}),0);org.junit.Assert.assertEquals(2.5,s.median(new int[]{4,1,3,2}),0);org.junit.Assert.assertEquals(java.util.List.of(2),s.mode(new int[]{2,1,2,3}));
    }
}
