package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE033 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.DecryptionUtils");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"caesarDecipher", "vigenereDecipher", "railFenceDecipher"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in DecryptionUtils", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        DecryptionUtils d=new DecryptionUtils("key");org.junit.Assert.assertEquals("Abc!",d.caesarDecipher("Def!",3));org.junit.Assert.assertEquals("ATTACKATDAWN",new DecryptionUtils("LEMON").vigenereDecipher("LXFOPVEFRNHR"));
    }
}
