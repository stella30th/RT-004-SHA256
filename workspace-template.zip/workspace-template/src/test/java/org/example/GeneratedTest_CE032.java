package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE032 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.DataStatistics4");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"correlationCoefficient", "skewness", "kurtosis", "pdf"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in DataStatistics4", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(1,DataStatistics4.correlationCoefficient(java.util.List.of(1.0,2.0,3.0),java.util.List.of(2.0,4.0,6.0)),1e-9);org.junit.Assert.assertEquals(0,DataStatistics4.skewness(java.util.List.of(1.0,2.0,3.0)),1e-9);org.junit.Assert.assertEquals(1.0/Math.sqrt(2*Math.PI),DataStatistics4.pdf(java.util.List.of(0.0),0,1).get(0),1e-9);
    }
}
