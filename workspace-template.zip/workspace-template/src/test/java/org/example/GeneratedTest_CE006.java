package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE006 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.AutomaticGuitarSimulator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"interpret", "display", "getChord", "getTune", "equals", "hashCode"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in AutomaticGuitarSimulator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        AutomaticGuitarSimulator s=new AutomaticGuitarSimulator("Am123 C4");org.junit.Assert.assertEquals(2,s.interpret(false).size());org.junit.Assert.assertEquals("Am",s.interpret(false).get(0).getChord());org.junit.Assert.assertEquals("123",s.interpret(false).get(0).getTune());org.junit.Assert.assertNull(new AutomaticGuitarSimulator(" ").interpret(false));
    }
}
