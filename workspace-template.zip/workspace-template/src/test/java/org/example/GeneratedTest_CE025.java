package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE025 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.ComplexCalculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"add", "subtract", "multiply", "divide", "getReal", "getImaginary", "equals", "toString"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in ComplexCalculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        ComplexCalculator c=new ComplexCalculator();ComplexCalculator.ComplexNumber a=new ComplexCalculator.ComplexNumber(1,2),b=new ComplexCalculator.ComplexNumber(3,4);org.junit.Assert.assertEquals(new ComplexCalculator.ComplexNumber(4,6),c.add(a,b));org.junit.Assert.assertEquals(new ComplexCalculator.ComplexNumber(-5,10),c.multiply(a,b));
    }
}
