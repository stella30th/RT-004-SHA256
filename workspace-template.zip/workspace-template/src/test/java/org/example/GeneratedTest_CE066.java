package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE066 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.PushBoxGame");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"checkWin", "move", "isGameOver", "getPlayerCol", "getPlayerRow", "getTargets", "getTargetCount", "getMap", "getBoxes"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in PushBoxGame", matched);
    }
}
