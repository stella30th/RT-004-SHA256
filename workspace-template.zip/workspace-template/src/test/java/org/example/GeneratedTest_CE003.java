package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE003 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.ArgumentParser");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"parseArguments", "getArgument", "addArgument"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in ArgumentParser", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        ArgumentParser p = new ArgumentParser(); p.addArgument("age",true,Integer.class); org.junit.Assert.assertFalse(p.parseArguments("cmd --other=x").x); org.junit.Assert.assertTrue(p.parseArguments("cmd --age=18").x); org.junit.Assert.assertEquals(18,p.getArgument("age"));
    }
}
