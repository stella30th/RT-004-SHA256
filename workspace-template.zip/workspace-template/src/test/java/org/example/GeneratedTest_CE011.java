package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE011 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BinaryDataProcessor");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"cleanNonBinaryChars", "calculateBinaryInfo", "convertToAscii", "convertToUtf8", "getBinaryString", "getZeroes", "getOnes", "getBitLength", "toString"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BinaryDataProcessor", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        BinaryDataProcessor p=new BinaryDataProcessor("0100 0001!");org.junit.Assert.assertEquals("01000001",p.getBinaryString());org.junit.Assert.assertEquals("A",p.convertToAscii());org.junit.Assert.assertEquals("A",p.convertToUtf8());org.junit.Assert.assertEquals(8,p.calculateBinaryInfo().getBitLength());
    }
}
