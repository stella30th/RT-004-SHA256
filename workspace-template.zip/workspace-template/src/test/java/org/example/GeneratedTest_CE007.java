package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE007 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.AvgPartition");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"setNum", "get"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in AvgPartition", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        AvgPartition a=new AvgPartition(java.util.List.of(1,2,3,4,5),2);org.junit.Assert.assertArrayEquals(new int[]{2,1},a.setNum());org.junit.Assert.assertEquals(java.util.List.of(1,2,3),a.get(0));org.junit.Assert.assertEquals(java.util.List.of(4,5),a.get(1));
    }
}
