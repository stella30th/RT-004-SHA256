package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE013 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BlackjackGame");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"checkWinner"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BlackjackGame", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        BlackjackGame b=new BlackjackGame();org.junit.Assert.assertEquals("Player wins",b.checkWinner(java.util.List.of("AS","KS"),java.util.List.of("9S","9H")));org.junit.Assert.assertEquals("Dealer wins",b.checkWinner(java.util.List.of("9S","9H"),java.util.List.of("AS","KS")));
    }
}
