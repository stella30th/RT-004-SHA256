package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE034 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.DiscountStrategy");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"total", "due", "promotion", "getName", "getFidelity", "addProduct", "getProducts", "getQuantity", "getPrice"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in DiscountStrategy", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        DiscountStrategy.Cart c=new DiscountStrategy.Cart(new DiscountStrategy.Product("A",20,10));DiscountStrategy d=new DiscountStrategy(new DiscountStrategy.Customer("u",1000),c,DiscountStrategy.FIDELITY_PROMO);org.junit.Assert.assertEquals(200,d.total(),0);org.junit.Assert.assertEquals(190,d.due(),0);DiscountStrategy b=new DiscountStrategy(new DiscountStrategy.Customer("u",0),c,DiscountStrategy.BULK_ITEM_PROMO);org.junit.Assert.assertEquals(180,b.due(),0);
    }
}
