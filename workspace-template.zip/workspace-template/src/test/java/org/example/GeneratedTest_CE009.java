package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE009 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.BankAccount");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"deposit", "withdraw", "viewBalance", "transfer"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in BankAccount", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        BankAccount a=new BankAccount(100),b=new BankAccount();org.junit.Assert.assertEquals(150,a.deposit(50));org.junit.Assert.assertEquals(130,a.withdraw(20));a.transfer(b,30);org.junit.Assert.assertEquals(100,a.viewBalance());org.junit.Assert.assertEquals(30,b.viewBalance());
    }
}
