package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE054 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.MetricsCalculator2");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"mrr", "map", "getList", "getTotalNum"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in MetricsCalculator2", matched);
    }
}
