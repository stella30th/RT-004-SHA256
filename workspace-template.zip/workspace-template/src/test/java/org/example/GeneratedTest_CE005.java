package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE005 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.AssessmentSystem");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"addStudent", "addCourseScore", "getGPA", "getAllStudentsWithFailCourse", "getCourseAverage", "getTopStudent", "getName", "calculateGPA", "hasFailingCourse", "getCourseScore", "equals", "hashCode"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in AssessmentSystem", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        AssessmentSystem s=new AssessmentSystem();s.addStudent("a",2,"CS");s.addStudent("b",3,"CS");s.addCourseScore("a","math",80);s.addCourseScore("a","eng",60);s.addCourseScore("b","math",50);org.junit.Assert.assertEquals(70.0,s.getGPA("a"),0.0);org.junit.Assert.assertEquals(65.0,s.getCourseAverage("math"),0.0);org.junit.Assert.assertTrue(s.getAllStudentsWithFailCourse().contains("b"));org.junit.Assert.assertEquals("a",s.getTopStudent());
    }
}
