package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE059 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.NLPDataProcessor2");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"getWord", "getFrequency", "toString", "equals", "hashCode", "byFrequencyThenWord", "processData", "calculateWordFrequency", "process"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in NLPDataProcessor2", matched);
    }
}
