package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE002 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.AreaCalculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"calculateCircleArea", "calculateSphereArea", "calculateCylinderArea", "calculateSectorArea", "calculateAnnulusArea"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in AreaCalculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        AreaCalculator a = new AreaCalculator(2); org.junit.Assert.assertEquals(4*Math.PI,a.calculateCircleArea(),1e-10); org.junit.Assert.assertEquals(16*Math.PI,a.calculateSphereArea(),1e-10); org.junit.Assert.assertEquals(20*Math.PI,a.calculateCylinderArea(3),1e-10); org.junit.Assert.assertEquals(2*Math.PI,a.calculateSectorArea(Math.PI),1e-10); org.junit.Assert.assertEquals(5*Math.PI,a.calculateAnnulusArea(2,3),1e-10);
    }
}
