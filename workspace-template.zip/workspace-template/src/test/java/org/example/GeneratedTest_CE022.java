package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE022 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.ClassRegistrationSystem");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"registerStudent", "registerClass", "getStudentsByMajor", "getAllMajor", "getMostPopularClassInMajor", "setStudents", "setStudentClasses", "getName", "getMajor", "equals", "hashCode"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in ClassRegistrationSystem", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        ClassRegistrationSystem s=new ClassRegistrationSystem();org.junit.Assert.assertEquals(1,s.registerStudent(new ClassRegistrationSystem.Student("Ada","CS")));org.junit.Assert.assertEquals(0,s.registerStudent(new ClassRegistrationSystem.Student("Ada","CS")));org.junit.Assert.assertEquals(java.util.List.of("Ada"),s.getStudentsByMajor("CS"));org.junit.Assert.assertEquals(java.util.List.of("Math"),s.registerClass("Ada","Math"));org.junit.Assert.assertEquals("Math",s.getMostPopularClassInMajor("CS"));
    }
}
