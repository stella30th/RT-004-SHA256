package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE020 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.ChandrasekharSieve");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"getPrimes"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in ChandrasekharSieve", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(java.util.List.of(2,3,5,7,11,13,17,19),new ChandrasekharSieve(20).getPrimes());org.junit.Assert.assertTrue(new ChandrasekharSieve(1).getPrimes().isEmpty());
    }
}
