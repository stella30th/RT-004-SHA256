package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE031 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.DataStatistics2");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"getSum", "getMin", "getMax", "getVariance", "getStdDeviation", "getCorrelation"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in DataStatistics2", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        DataStatistics2 d=new DataStatistics2(java.util.List.of(1,2,3));org.junit.Assert.assertEquals(6,d.getSum(),0);org.junit.Assert.assertEquals(1,d.getMin(),0);org.junit.Assert.assertEquals(3,d.getMax(),0);org.junit.Assert.assertEquals(2.0/3,d.getVariance(),1e-10);org.junit.Assert.assertEquals(1,d.getCorrelation(),0);
    }
}
