package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE021 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.Chat");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"addUser", "removeUser", "sendMessage", "getMessages", "getUsers", "getSender", "getReceiver", "getMessage", "getTimestamp", "equals", "hashCode", "toString"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in Chat", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        Chat c=new Chat();org.junit.Assert.assertTrue(c.addUser("a"));org.junit.Assert.assertFalse(c.addUser("a"));org.junit.Assert.assertTrue(c.addUser("b"));org.junit.Assert.assertTrue(c.sendMessage("a","b","hi"));org.junit.Assert.assertEquals(1,c.getMessages("a").size());org.junit.Assert.assertEquals(1,c.getMessages("b").size());org.junit.Assert.assertTrue(c.removeUser("a"));
    }
}
