package org.example;

import org.junit.Test;
import static org.junit.Assert.*;

public class GeneratedTest_CE004 {
    @Test
    public void sourceDeclaredApiIsPresent() throws Exception {
        Class<?> target = Class.forName("org.example.ArrangementCalculator");
        java.util.Set<String> methodNames = new java.util.HashSet<>();
        for (java.lang.reflect.Method method : target.getDeclaredMethods()) methodNames.add(method.getName());
        boolean matched = false;
        for (String methodName : new String[]{"count", "countAll", "select", "selectAll", "factorial"}) if (methodNames.contains(methodName)) matched = true;
        assertTrue("No declared API method found in ArrangementCalculator", matched);
    }

    @Test
    public void behaviorFromProvidedSource() throws Exception {
        org.junit.Assert.assertEquals(6,ArrangementCalculator.count(3,null));org.junit.Assert.assertEquals(6,ArrangementCalculator.count(3,2));org.junit.Assert.assertEquals(15,ArrangementCalculator.countAll(3));org.junit.Assert.assertEquals(6,new ArrangementCalculator(new java.util.ArrayList<Object>(java.util.List.of("a","b","c"))).select(2).size());
    }
}
